import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-city-radius',
  templateUrl: './city-radius.component.html',
  styleUrls: ['./city-radius.component.css']
})
export class CityRadiusComponent implements OnInit {
  title="City and Radius";

  constructor() { }

  ngOnInit(): void {}
}